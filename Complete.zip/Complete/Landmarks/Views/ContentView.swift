/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing featured landmarks above a list of all of the landmarks.
*/

import SwiftUI

struct ContentView: View {
    @State private var selection: Tab = .featured

    enum Tab {
        case featured
        case list1
        case list2
    }

    var body: some View {
        TabView(selection: $selection) {
            CategoryHome()
                .tabItem {
                    Label("About Me", systemImage: "person")
                }
                .tag(Tab.featured)

            ExperienceList()
                .tabItem {
                    Label("Experience", systemImage: "doc.on.doc")
                }
                .tag(Tab.list1)
            InterviewList()
                .tabItem {
                    Label("Questions", systemImage: "speaker.1")
                }
                .tag(Tab.list2)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(ModelData())
    }
}
