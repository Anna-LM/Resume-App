/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a list of profiles.
*/

import SwiftUI

struct HobbyList: View {
    @EnvironmentObject var modelData: ModelData



    var body: some View {
        NavigationView {
            List {

                ForEach( modelData.hobbys) { hobby in
                    NavigationLink {
                        HobbyDetail(hobby: hobby)
                    } label: {
                        HobbyRow(hobby: hobby)
                    }
                    .padding(0)
                    
                }
            }
            .navigationTitle("Profile Questions")
        }
    }
}

struct HobbyList_Previews: PreviewProvider {
    static var previews: some View {
        HobbyList()
            .environmentObject(ModelData())
    }
}
