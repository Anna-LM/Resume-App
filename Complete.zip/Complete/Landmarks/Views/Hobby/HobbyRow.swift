/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A single row to be displayed in a list of landmarks.
*/

import SwiftUI

struct HobbyRow: View {
    var hobby: Hobby

    var body: some View {
        HStack {

            Text(hobby.Topic).padding(0)

            //Spacer()

        }
    }
}

struct HobbyRow_Previews: PreviewProvider {
    static var hobby = ModelData().hobbys

    static var previews: some View {
        Group {
            //ProfileRow(profile: profiles[0])
            //ProfileRow(profile: profiles[1])
        }
        //.previewLayout(.fixed(width: 300, height: 70))
    }
}
