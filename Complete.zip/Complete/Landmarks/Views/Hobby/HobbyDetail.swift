/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing the details for a hobby.
*/

import SwiftUI

struct HobbyDetail: View {
    @EnvironmentObject var modelData: ModelData
    var hobby: Hobby

    var hobbyIndex: Int {
        modelData.hobbys.firstIndex(where: { $0.id == hobby.id })!
    }

    var body: some View {
        ScrollView {
            

            VStack(alignment: .leading) {
                Text(hobby.Topic)
                    .font(.title)

                Divider()

                Text(hobby.Discussion)
            }
            .padding()
        }
        .navigationTitle(hobby.Topic)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct HobbyDetail_Previews: PreviewProvider {
    static let modelData = ModelData()

    static var previews: some View {
        HobbyDetail(hobby: modelData.hobbys[0])
            .environmentObject(modelData)
    }
}
