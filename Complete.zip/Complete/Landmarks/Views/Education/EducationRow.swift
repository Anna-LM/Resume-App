/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A single row to be displayed in a list of landmarks.
*/

import SwiftUI

struct EducationRow: View {
    var education: Education

    var body: some View {
        HStack {

            
            Text(education.Topic).padding()
            Spacer()

            //Spacer()Text(education.Topic)

        }
    }
}

struct EducationRow_Previews: PreviewProvider {
    static var education = ModelData().educations

    static var previews: some View {
        Group {
            //EducationRow(education: educations[0])
            //EducationRow(education: educations[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))
    }
}
