/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a list of educations.
*/

import SwiftUI

struct EducationList: View {
    @EnvironmentObject var modelData: ModelData



    var body: some View {
        NavigationView {
            List {

                ForEach( modelData.educations) { education in
                    NavigationLink {
                        EducationDetail(education: education)
                    } label: {
                        EducationRow(education: education)
                    }
                }
            }
            .navigationTitle("Education Questions")
        }
    }
}

struct EducationList_Previews: PreviewProvider {
    static var previews: some View {
        EducationList()
            .environmentObject(ModelData())
    }
}
