/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing the details for a education.
*/

import SwiftUI

struct EducationDetail: View {
    @EnvironmentObject var modelData: ModelData
    var education: Education

    var educationIndex: Int {
        modelData.educations.firstIndex(where: { $0.id == education.id })!
    }

    var body: some View {
        ScrollView {
            

            //VStack(alignment: .leading) {
            //    Text(education.Topic)
            //        .font(.title)

            //    Divider()

            //    Text(education.Discussion)
            //}
            //.padding()
            
            
            MapView(backgroundimage: education.backgroundimage)
                //.ignoresSafeArea(edges: .top)
                .frame(maxWidth: 300)
            

            CircleImage(image: education.image)
                .offset(y: -130)
                .padding(.bottom, -130)

            VStack(alignment: .leading) {
                HStack {
                    Text(education.Topic)
                        .font(.title)
                    
                }
                Text(education.role)
                    .font(.title2)
                HStack {
                    Text(education.date)
                    Spacer()
                    Text(education.location)
                    
                }
                .font(.subheadline)
                .foregroundColor(.secondary)

                Divider()

                Text("Modules")
                    .font(.title2)
                Text(education.Discussion)
            }
            .padding()
            
            
            
            
            
        }
        .navigationTitle(education.Topic)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct EducationDetail_Previews: PreviewProvider {
    static let modelData = ModelData()

    static var previews: some View {
        EducationDetail(education: modelData.educations[0])
            .environmentObject(modelData)
    }
}
