/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a list of profiles.
*/

import SwiftUI

struct ProfileList: View {
    @EnvironmentObject var modelData: ModelData



    var body: some View {
        NavigationView {
            List {

                ForEach( modelData.profiles) { profile in
                    NavigationLink {
                        ProfileDetail(profile: profile)
                    } label: {
                        ProfileRow(profile: profile)
                    }
                }
            }
            .navigationTitle("Profile Questions")
        }
    }
}

struct ProfileList_Previews: PreviewProvider {
    static var previews: some View {
        ProfileList()
            .environmentObject(ModelData())
    }
}
