/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing the details for a profile.
*/

import SwiftUI

struct ProfileDetail: View {
    @EnvironmentObject var modelData: ModelData
    var profile: Profile

    var profileIndex: Int {
        modelData.profiles.firstIndex(where: { $0.id == profile.id })!
    }

    var body: some View {
        ScrollView {
            CircleImage(image: profile.image)
                .offset(y: 0)
                .padding(.bottom, 1)

            VStack(alignment: .leading) {
                Text(profile.Topic)
                    .font(.title)

                Divider()

                Text(profile.Discussion)
            }
            .padding()
        }
        .navigationTitle(profile.Topic)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ProfileDetail_Previews: PreviewProvider {
    static let modelData = ModelData()

    static var previews: some View {
        ProfileDetail(profile: modelData.profiles[0])
            .environmentObject(modelData)
    }
}
