/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A single row to be displayed in a list of landmarks.
*/

import SwiftUI

struct ProfileRow: View {
    var profile: Profile

    var body: some View {
        HStack {

            Text(profile.Topic).padding()

            Spacer()

        }
    }
}

struct ProfileRow_Previews: PreviewProvider {
    static var profile = ModelData().profiles

    static var previews: some View {
        Group {
            //ProfileRow(profile: profiles[0])
            //ProfileRow(profile: profiles[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))
    }
}
