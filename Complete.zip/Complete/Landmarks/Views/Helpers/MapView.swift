/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view that presents a map of a landmark.
*/

import SwiftUI
struct MapView: View {
    var backgroundimage: Image

    var body: some View {
        backgroundimage
            .clipShape(Rectangle())
            //.overlay {
            //    Circle().stroke(.white, lineWidth: 4)
            //}
            //.shadow(radius: 7)
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView(backgroundimage: Image("turtlerock"))
    }
}
