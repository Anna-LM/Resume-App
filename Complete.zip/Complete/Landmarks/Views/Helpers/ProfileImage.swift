//
//  ProfileImage.swift
//  Anna's CV
//
//  Created by Anna Llambias Maw on 25/10/2023.
//  Copyright © 2023 Apple. All rights reserved.
//

import SwiftUI

struct ProfileImage: View {
    var image: Image

    var body: some View {
        image
            .clipShape(Circle())
            .overlay {
                Circle().stroke(.white, lineWidth: 2)
                
            }
            .shadow(radius: 3)
    }
}

struct ProfileImage_Previews: PreviewProvider {
    static var previews: some View {
        ProfileImage(image: Image("turtlerock"))
    }
}
