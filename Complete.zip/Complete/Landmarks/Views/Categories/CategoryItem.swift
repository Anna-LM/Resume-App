/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a single category item.
*/

import SwiftUI

struct CategoryItem: View {
    var hobby: Hobby

    var body: some View {
        VStack(alignment: .leading) {
            hobby.image
                .renderingMode(.original)
                .resizable()
                .frame(width: 70, height: 70)
                .cornerRadius(5)
            //Text(profile.Topic)
            //    .frame(width: 75)
            //    .background(.blue)
            //    .foregroundColor(.primary)
            //    .multilineTextAlignment(.center)
            //    .li#imageLiteral(resourceName: "goal.png")neLimit(nil)
            //    .font(.caption)
        }
        .padding(.leading, 2)
    }
}

struct CategoryItem_Previews: PreviewProvider {
    static var previews: some View {
        CategoryItem(hobby: ModelData().hobbys[0])
    }
}
