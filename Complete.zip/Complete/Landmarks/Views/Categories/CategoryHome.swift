/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing featured landmarks above a list of landmarks grouped by category.
*/

import SwiftUI

struct CategoryHome: View {
    @EnvironmentObject var modelData: ModelData

    var body: some View {
        NavigationView {
            List {
                //modelData.features[0].image
                //MapView(backgroundimage: Image("turtlerock"))
                Image("uclgradcropped")
                    .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 400, height: 200, alignment: .topLeading)
                    .listRowInsets(EdgeInsets())
                    //.padding(.bottom, 2)
                
                Text("Profile")
                    .font(.headline)
                    .padding(.leading, 5)
                    .padding(.top, 5)

                ForEach(modelData.profiles) { profile in
                    NavigationLink {
                        ProfileDetail(profile: profile)
                    } label: {
                        ProfileRow(profile: profile)
                            .padding(.leading, 5)
                            .padding(.top, 5)
                    }
                }
                
            
                    .listRowInsets(EdgeInsets())
                Text("Education")
                    .font(.headline)
                    .padding(.leading, 5)
                    .padding(.top, 5)
 
                ForEach(modelData.educations) { education in
                    NavigationLink {
                        EducationDetail(education: education)
                    } label: {
                        EducationRow(education: education)
                            .padding(.leading, 5)
                            .padding(.top, 5)
                    }
                }
                
                    .listRowInsets(EdgeInsets())

               
                Text("Links")
                    .font(.headline)
                    .padding(.leading, 5)
                    .padding(.top, 5)
                HStack {
                    Link(destination: URL(string: "https://www.linkedin.com/in/anna-llambias-maw-6b065a205")!, label: {
                        Image("linkedin")
                            .resizable()
                            .frame(width: 70, height: 70)
                    })
                    
                    Link(destination: URL(string: "https://github.com/anna-lm")!, label: {
                        Image("github")
                            .resizable()
                            .frame(width: 70, height: 70)
                    })
                    
                    Link(destination: URL(string: "https://aclm.pythonanywhere.com/#employment")!, label: {
                        Image("www")
                            .resizable()
                            .frame(width: 70, height: 70)
                    })
                    
                }
                //.listRowInsets(EdgeInsets())
                Text("Qualifications")
                    .font(.headline)
                    .padding(.leading, 5)
                    .padding(.top, 5)
                ScrollView(.horizontal) {
                    HStack {
                        Link(destination: URL(string: "https://mhfaengland.org")!, label: {
                            Image("mhfa")
                                .resizable()
                                .frame(width: 70, height: 70)
                        })
                        Link(destination: URL(string: "https://www.rlss.org.uk/first-aid-at-work")!, label: {
                            Image("first aid")
                                .resizable()
                                .frame(width: 70, height: 70)
                        })
                        
                        Link(destination: URL(string: "https://www.dofe.org")!, label: {
                            Image("dofe")
                                .resizable()
                                .frame(width: 70, height: 70)
                        })
                        
                        Link(destination: URL(string: "https://www.mulesoft.com")!, label: {
                            Image("mulesoft")
                                .resizable()
                                .frame(width: 70, height: 70)
                        })
                        
                        Link(destination: URL(string: "https://www.tableau.com")!, label:
                            {
                            Image("tableau")
                                .resizable()
                                .frame(width: 70, height: 70)
                        })
                        Link(destination: URL(string:"https://www.microsoft.com/en-gb/")!, label: {
                            Image("microsoft")
                                .resizable()
                                .frame(width: 70, height: 70)
                        })
                    }
                }
                //.listRowInsets(EdgeInsets())
                
                ForEach(modelData.categories.keys.reversed(), id: \.self) { key in
                    CategoryRow(categoryName: key, items: modelData.categories[key]!)
                }
                .listRowInsets(EdgeInsets())
                
            }
            .navigationTitle("Anna Llambias Maw")
        }
        
    }
}

struct CategoryHome_Previews: PreviewProvider {
    static var previews: some View {
        CategoryHome()
            .environmentObject(ModelData())
    }
}
