/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing the details for a landmark.
*/

import SwiftUI

struct ExperienceDetail: View {
    @EnvironmentObject var modelData: ModelData
    var experience: Experience

    var landmarkIndex: Int {
        modelData.experiences.firstIndex(where: { $0.id == experience.id })!
    }

    var body: some View {
        ScrollView {
            MapView(backgroundimage: experience.backgroundimage)
                //.ignoresSafeArea(edges: .top)
                .frame(maxWidth: 300)
            

            CircleImage(image: experience.image)
                .offset(y: -130)
                .padding(.bottom, -130)

            VStack(alignment: .leading) {
                HStack {
                    Text(experience.name)
                        .font(.title)
                    
                }
                Text(experience.role)
                    .font(.title2)
                HStack {
                    Text(experience.date)
                    Spacer()
                    Text(experience.location)
                    
                }
                .font(.subheadline)
                .foregroundColor(.secondary)

                Divider()

                Text("About \(experience.name)")
                    .font(.title2)
                Text(experience.description)
            }
            .padding()
        }
        .navigationTitle(experience.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ExperienceDetail_Previews: PreviewProvider {
    static let modelData = ModelData()

    static var previews: some View {
        ExperienceDetail(experience: modelData.experiences[0])
            .environmentObject(modelData)
    }
}
