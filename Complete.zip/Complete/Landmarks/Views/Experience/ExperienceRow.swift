/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A single row to be displayed in a list of landmarks.
*/

import SwiftUI

struct ExperienceRow: View {
    var experience: Experience

    var body: some View {
        HStack {
            experience.image
                .resizable()
                .frame(width: 50, height: 50)
            Text(experience.name)

            Spacer()

            
        }
    }
}

struct ExperienceRow_Previews: PreviewProvider {
    static var experiences = ModelData().experiences

    static var previews: some View {
        Group {
            ExperienceRow(experience: experiences[0])
            ExperienceRow(experience: experiences[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))
    }
}
