/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a list of landmarks.
*/

import SwiftUI

struct ExperienceList: View {
    @EnvironmentObject var modelData: ModelData
    @State private var showFavoritesOnly = false

    
    var body: some View {
        NavigationView {
            List {

                ForEach(modelData.experiences) { experience in
                    NavigationLink {
                        ExperienceDetail(experience: experience)
                    } label: {
                        ExperienceRow(experience: experience)
                    }
                }
            }
            .navigationTitle("Experiences")
        }
    }
}

struct ExperienceList_Previews: PreviewProvider {
    static var previews: some View {
        ExperienceList()
            .environmentObject(ModelData())
    }
}
