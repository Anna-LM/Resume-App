/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a list of interviews.
*/

import SwiftUI

struct InterviewList: View {
    @EnvironmentObject var modelData: ModelData



    var body: some View {
        NavigationView {
            List {

                ForEach( modelData.interviews) { interview in
                    NavigationLink {
                        InterviewDetail(interview: interview)
                    } label: {
                        InterviewRow(interview: interview)
                    }
                }
            }
            .navigationTitle("Interview Questions")
        }
    }
}

struct InterviewList_Previews: PreviewProvider {
    static var previews: some View {
        InterviewList()
            .environmentObject(ModelData())
    }
}
