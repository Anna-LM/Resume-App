/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing the details for a interview.
*/

import SwiftUI

struct InterviewDetail: View {
    @EnvironmentObject var modelData: ModelData
    var interview: Interview

    var interviewIndex: Int {
        modelData.interviews.firstIndex(where: { $0.id == interview.id })!
    }

    var body: some View {
        ScrollView {
            

            VStack(alignment: .leading) {
                Text(interview.question)
                    .font(.title)

                Divider()

                Text(interview.answer)
            }
            .padding()
        }
        .navigationTitle(interview.question)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct InterviewDetail_Previews: PreviewProvider {
    static let modelData = ModelData()

    static var previews: some View {
        InterviewDetail(interview: modelData.interviews[0])
            .environmentObject(modelData)
    }
}
