/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A single row to be displayed in a list of landmarks.
*/

import SwiftUI

struct InterviewRow: View {
    var interview: Interview

    var body: some View {
        HStack {

            Text(interview.question)

            Spacer()

        }
    }
}

struct InterviewRow_Previews: PreviewProvider {
    static var interview = ModelData().interviews

    static var previews: some View {
        Group {
            //InterviewRow(interview: interviews[0])
            //InterviewRow(interview: interviews[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))
    }
}
