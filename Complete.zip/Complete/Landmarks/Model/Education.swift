/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A representation of a single landmark.
*/

import Foundation
import SwiftUI
import CoreLocation

struct Education: Hashable, Codable, Identifiable {
    var id: Int
    var Topic: String
    var Discussion: String
    var role: String
    var date: String
    var location: String
   
    private var imageName: String
    var image: Image {
        Image(imageName)
    }
    private var imagebackground: String
    var backgroundimage: Image {
        Image(imagebackground)
    }
    
}
