/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A representation of a single landmark.
*/

import Foundation
import SwiftUI
import CoreLocation

struct Hobby: Hashable, Codable, Identifiable {
    var id: Int
    var Topic: String
    var Discussion: String
    var category: Category
    enum Category: String, CaseIterable, Codable {
        case Hobbies = "Hobbies"
        case qualifications = "Qualifications"
        case links = "Links"
    }
    private var imageName: String
    var image: Image {
        Image(imageName)
    }
    
}
