/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A representation of a single landmark.
*/

import Foundation
import SwiftUI
import CoreLocation

struct Interview: Hashable, Codable, Identifiable {
    var id: Int
    var question: String
    var answer: String
    
}
